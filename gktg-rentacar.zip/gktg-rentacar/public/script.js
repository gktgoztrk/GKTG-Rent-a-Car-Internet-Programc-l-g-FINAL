document.addEventListener('DOMContentLoaded', function() {
    const searchForm = document.getElementById('search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(event) {
            event.preventDefault(); 

            const pickupLocation = document.getElementById('pickup-location').value;
            const dropoffLocation = document.getElementById('dropoff-location').value;
            const pickupDate = document.getElementById('pickup-date').value;
            const dropoffDate = document.getElementById('dropoff-date').value;

            console.log('Arama Yapılıyor:');
            console.log('Alış Yeri:', pickupLocation);
            console.log('Bırakma Yeri:', dropoffLocation);
            console.log('Alış Tarihi:', pickupDate);
            console.log('Bırakma Tarihi:', dropoffDate);

            localStorage.setItem('pickupLocation', pickupLocation);
            localStorage.setItem('dropoffLocation', dropoffLocation);
            localStorage.setItem('pickupDate', pickupDate);
            localStorage.setItem('dropoffDate', dropoffDate);

           
            window.location.href = 'index.html';
        });
    }

    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(event) {
            event.preventDefault();

            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const pickupLocation = localStorage.getItem('pickupLocation');
            const dropoffLocation = localStorage.getItem('dropoffLocation');
            const pickupDate = localStorage.getItem('pickupDate');
            const dropoffDate = localStorage.getItem('dropoffDate');

            console.log('Başvuru Gönderiliyor:');
            console.log('Adınız:', name);
            console.log('E-posta:', email);
            console.log('Telefon:', phone);
            console.log('Alış Yeri:', pickupLocation);
            console.log('Bırakma Yeri:', dropoffLocation);
            console.log('Alış Tarihi:', pickupDate);
            console.log('Bırakma Tarihi:', dropoffDate);

            
            fetch('/submit', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name: name,
                    email: email,
                    phone: phone,
                    pickupLocation: pickupLocation,
                    dropoffLocation: dropoffLocation,
                    pickupDate: pickupDate,
                    dropoffDate: dropoffDate
                })
            })
            .then(response => response.text())
            .then(data => {
                console.log(data);
                alert('Başvurunuz başarıyla gönderildi!');
                
                localStorage.clear();
                
                window.location.href = 'index.html';
            })
            .catch(error => {
                console.error('Hata:', error);
                alert('Bir hata oluştu. Lütfen tekrar deneyin.');
            });
        });
    }
});
