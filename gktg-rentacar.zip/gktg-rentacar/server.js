const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public')); // Statik dosyaları sunmak için

// Anasayfa
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

// İletişim sayfası
app.get('/contact.html', (req, res) => {
    res.sendFile(__dirname + '/public/contact.html');
});

// Araçlar sayfası
app.get('/cars.html', (req, res) => {
    res.sendFile(__dirname + '/public/cars.html');
});

// Hakkımızda sayfası
app.get('/about.html', (req, res) => {
    res.sendFile(__dirname + '/public/about.html');
});

// İletişim form verilerini işleme
app.post('/contact', (req, res) => {
    console.log('Mesaj verileri alındı:', req.body);

    const { name, email, message } = req.body;
    console.log(`Adınız: ${name}, E-posta: ${email}, Mesaj: ${message}`);

    const contactData = `Adınız: ${name}, E-posta: ${email}, Mesaj: ${message}\n`;

    // Verileri bir dosyaya UTF-8 olarak yazma
    fs.writeFileSync('contactData.txt', contactData, { encoding: 'utf8', flag: 'a' });
    console.log('Mesaj verileri kaydedildi.');
    res.send('Mesaj başarıyla gönderildi!');
});

// Form verilerini işleme
app.post('/submit', (req, res) => {
    console.log('Form verileri alındı:', req.body); // Form verilerini konsola yazdırma

    const { name, email, phone, pickupLocation, dropoffLocation, pickupDate, dropoffDate } = req.body;
    console.log(`Adınız: ${name}, E-posta: ${email}, Telefon: ${phone}, Alış Yeri: ${pickupLocation}, Bırakma Yeri: ${dropoffLocation}, Alış Tarihi: ${pickupDate}, Bırakma Tarihi: ${dropoffDate}`);

    const formData = `Adınız: ${name}, E-posta: ${email}, Telefon: ${phone}, Alış Yeri: ${pickupLocation}, Bırakma Yeri: ${dropoffLocation}, Alış Tarihi: ${pickupDate}, Bırakma Tarihi: ${dropoffDate}\n`;

    // Verileri bir dosyaya UTF-8 olarak yazma
    fs.writeFileSync('formData.txt', formData, { encoding: 'utf8', flag: 'a' });
    console.log('Form verileri kaydedildi.');
    res.send('Form başarıyla gönderildi!');
});

app.listen(PORT, () => {
    console.log(`Sunucu ${PORT} portunda çalışıyor.`);
});
